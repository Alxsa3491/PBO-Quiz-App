/* 
* Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Quiz;

import Quiz.Question;
import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
/**
 *
 * @author HP
 */
public class QuizFrame extends JFrame {

    private final JLabel lblTitle = new JLabel("Quiz Bahasa Jepang");
    private final JLabel lblProgress = new JLabel("Question 1/1");
    private final JLabel lblTimer = new JLabel("Time: 01:00");

    private final JTextArea txtQuestion = new JTextArea();
    private final JButton[] btnOptions = new JButton[4];
    private final JButton btnNext = new JButton("Next");

    private final ArrayList<Question> questions = new ArrayList<>();
    private int currentIndex = 0;
    private int score = 0;
    private boolean answered = false;

    // ===== Timer per soal
    private static final int SECONDS_PER_QUESTION = 60;
    private int remainingSeconds = SECONDS_PER_QUESTION;
    private final Timer questionTimer;

    public QuizFrame() {
        setTitle("Quiz App (Swing)");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700, 450);
        setLocationRelativeTo(null);

        initQuestions();
        initUI();
        loadQuestion();

        questionTimer = new Timer(1000, e -> onTimerTick());
        questionTimer.start();
    }

    private void initQuestions() {
        questions.clear();

        // ====== 20 SOAL PEMBELAJARAN BAHASA JEPANG ======
        // correctIndex: A=0, B=1, C=2, D=3

        questions.add(new Question(
                "1) Hiragana untuk bunyi 'a' adalah...",
                new String[]{"あ", "い", "う", "え"},
                0
        ));
        questions.add(new Question(
                "2) Hiragana untuk bunyi 'ka' adalah...",
                new String[]{"か", "さ", "た", "な"},
                0
        ));
        questions.add(new Question(
                "3) Katakana untuk bunyi 'a' adalah...",
                new String[]{"ア", "イ", "ウ", "エ"},
                0
        ));
        questions.add(new Question(
                "4) Arti ねこ (neko) adalah...",
                new String[]{"Anjing", "Kucing", "Burung", "Ikan"},
                1
        ));
        questions.add(new Question(
                "5) Arti いぬ (inu) adalah...",
                new String[]{"Kucing", "Anjing", "Kelinci", "Kuda"},
                1
        ));
        questions.add(new Question(
                "6) Arti おはよう (ohayou) adalah...",
                new String[]{"Selamat pagi", "Selamat malam", "Permisi", "Terima kasih"},
                0
        ));
        questions.add(new Question(
                "7) ありがとう (arigatou) artinya...",
                new String[]{"Terima kasih", "Maaf", "Sama-sama", "Selamat datang"},
                0
        ));
        questions.add(new Question(
                "8) 'さようなら (sayounara)' artinya...",
                new String[]{"Selamat datang", "Selamat tinggal", "Selamat makan", "Selamat pagi"},
                1
        ));
        questions.add(new Question(
                "9) Angka 1 dalam bahasa Jepang adalah...",
                new String[]{"いち (ichi)", "に (ni)", "さん (san)", "よん (yon)"},
                0
        ));
        questions.add(new Question(
                "10) Angka 3 dalam bahasa Jepang adalah...",
                new String[]{"いち (ichi)", "に (ni)", "さん (san)", "ご (go)"},
                2
        ));
        questions.add(new Question(
                "11) Kata untuk 'air' adalah...",
                new String[]{"みず (mizu)", "ひ (hi)", "つき (tsuki)", "やま (yama)"},
                0
        ));
        questions.add(new Question(
                "12) '学校 (がっこう / gakkou)' artinya...",
                new String[]{"Sekolah", "Rumah", "Kantor", "Pasar"},
                0
        ));
        questions.add(new Question(
                "13) '先生 (せんせい / sensei)' artinya...",
                new String[]{"Guru/Dosen", "Murid", "Teman", "Dokter"},
                0
        ));
        questions.add(new Question(
                "14) Partikel は (wa) berfungsi sebagai...",
                new String[]{"Penanda objek", "Penanda topik", "Penanda tempat", "Penanda kepemilikan"},
                1
        ));
        questions.add(new Question(
                "15) Partikel を (o) biasanya menandai...",
                new String[]{"Objek langsung", "Topik", "Kepemilikan", "Waktu"},
                0
        ));
        questions.add(new Question(
                "16) Kata tanya 'apa' adalah...",
                new String[]{"だれ (dare)", "どこ (doko)", "なに (nani)", "いつ (itsu)"},
                2
        ));
        questions.add(new Question(
                "17) Kata tanya 'siapa' adalah...",
                new String[]{"どこ (doko)", "だれ (dare)", "どれ (dore)", "なに (nani)"},
                1
        ));
        questions.add(new Question(
                "18) Arti 'たべます (tabemasu)' adalah...",
                new String[]{"Minum", "Makan", "Pergi", "Tidur"},
                1
        ));
        questions.add(new Question(
                "19) Bentuk negatif sopan dari 'たべます (tabemasu)' adalah...",
                new String[]{"たべません (tabemasen)", "たべました (tabemashita)", "たべない (tabenai)", "たべて (tabete)"},
                0
        ));
        questions.add(new Question(
                "20) 'にほんご (nihongo)' artinya...",
                new String[]{"Bahasa Jepang", "Orang Jepang", "Negara Jepang", "Buku Jepang"},
                0
        ));
    }

    private void initUI() {
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 22));
        lblTimer.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblProgress.setFont(new Font("SansSerif", Font.PLAIN, 12));

        JPanel headerRight = new JPanel();
        headerRight.setLayout(new BoxLayout(headerRight, BoxLayout.Y_AXIS));
        headerRight.add(lblTimer);
        headerRight.add(Box.createVerticalStrut(6));
        headerRight.add(lblProgress);

        JPanel header = new JPanel(new BorderLayout());
        header.setBorder(BorderFactory.createEmptyBorder(12, 14, 8, 14));
        header.add(lblTitle, BorderLayout.WEST);
        header.add(headerRight, BorderLayout.EAST);

        txtQuestion.setEditable(false);
        txtQuestion.setLineWrap(true);
        txtQuestion.setWrapStyleWord(true);
        txtQuestion.setFont(new Font("SansSerif", Font.PLAIN, 16));
        txtQuestion.setBackground(new Color(245, 245, 245));
        txtQuestion.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel questionPanel = new JPanel(new BorderLayout());
        questionPanel.setBorder(BorderFactory.createEmptyBorder(0, 14, 8, 14));
        questionPanel.add(txtQuestion, BorderLayout.CENTER);

        JPanel optionsPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        optionsPanel.setBorder(BorderFactory.createEmptyBorder(0, 14, 10, 14));

        for (int i = 0; i < 4; i++) {
            final int idx = i;
            btnOptions[i] = new JButton("Option " + (i + 1));
            btnOptions[i].setFont(new Font("SansSerif", Font.PLAIN, 15));
            btnOptions[i].setFocusPainted(false);
            btnOptions[i].setBackground(Color.WHITE);
            btnOptions[i].setOpaque(true);
            btnOptions[i].addActionListener(e -> onOptionSelected(idx));
            optionsPanel.add(btnOptions[i]);
        }

        btnNext.setEnabled(false);
        btnNext.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnNext.addActionListener(e -> nextQuestion());

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footer.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));
        footer.add(btnNext);

        setLayout(new BorderLayout());
        add(header, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout());
        center.add(questionPanel, BorderLayout.NORTH);
        center.add(optionsPanel, BorderLayout.CENTER);

        add(center, BorderLayout.CENTER);
        add(footer, BorderLayout.SOUTH);
    }

    private void loadQuestion() {
        answered = false;
        btnNext.setEnabled(false);

        resetQuestionTimer();
        updateTimerLabel();

        for (JButton b : btnOptions) {
            b.setEnabled(true);
            b.setBackground(Color.WHITE);
            b.setForeground(Color.BLACK);
        }

        Question q = questions.get(currentIndex);
        lblProgress.setText("Question " + (currentIndex + 1) + "/" + questions.size());
        txtQuestion.setText(q.getText());

        String[] ops = q.getOptions();
        for (int i = 0; i < 4; i++) {
            btnOptions[i].setText(ops[i]);
        }
    }

    private void onOptionSelected(int selectedIndex) {
        if (answered) return;
        answered = true;

        Question q = questions.get(currentIndex);
        int correct = q.getCorrectIndex();

        // stop timer kalau sudah menjawab
        questionTimer.stop();

        for (JButton b : btnOptions) b.setEnabled(false);

        // tandai jawaban benar hijau
        btnOptions[correct].setBackground(new Color(170, 240, 170));

        // kalau salah, tandai yang dipilih merah
        if (selectedIndex != correct) {
            btnOptions[selectedIndex].setBackground(new Color(255, 170, 170));
        } else {
            score++;
        }

        btnNext.setEnabled(true);
    }

    private void nextQuestion() {
        currentIndex++;

        if (currentIndex >= questions.size()) {
            showResult();
            return;
        }

        // mulai timer lagi untuk soal berikutnya
        questionTimer.start();
        loadQuestion();
    }

    private void showResult() {
        questionTimer.stop();

        int total = questions.size();
        JOptionPane.showMessageDialog(
                this,
                "Quiz Finished!\nScore: " + score + " / " + total,
                "Result",
                JOptionPane.INFORMATION_MESSAGE
        );

        // reset quiz
        currentIndex = 0;
        score = 0;
        questionTimer.start();
        loadQuestion();
    }

    // ===== Timer logic =====

    private void resetQuestionTimer() {
        remainingSeconds = SECONDS_PER_QUESTION;
    }

    private void onTimerTick() {
        if (answered) return;

        remainingSeconds--;
        updateTimerLabel();

        if (remainingSeconds <= 0) {
            forceTimeoutAndMoveNext(); // <- habis waktu: langsung next & dianggap salah
        }
    }

    private void updateTimerLabel() {
        int m = remainingSeconds / 60;
        int s = remainingSeconds % 60;
        lblTimer.setText(String.format("Time: %02d:%02d", m, s));
    }

    // Timer habis -> langsung lanjut, skor tidak bertambah (dianggap salah)
    private void forceTimeoutAndMoveNext() {
        answered = true;

        // disable tombol supaya tidak sempat klik saat pindah
        for (JButton b : btnOptions) b.setEnabled(false);

        // langsung next
        SwingUtilities.invokeLater(this::nextQuestion);
    }
}
